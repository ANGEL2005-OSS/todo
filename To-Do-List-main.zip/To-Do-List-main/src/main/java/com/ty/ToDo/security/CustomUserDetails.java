package com.ty.ToDo.security;

public class CustomUserDetails {

}
